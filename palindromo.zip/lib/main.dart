import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Palindromo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final TextEditingController _textController = TextEditingController();
  String _resultado = '';

  bool esPalindromo(String cadena) {
    final cadenaLimpia = cadena.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
    return cadenaLimpia == cadenaLimpia.split('').reversed.join('');
  }

  void _verificarPalindromo() {
    final texto = _textController.text;
    setState(() {
      if (texto.isEmpty) {
        _resultado = 'Error';
      } else if (esPalindromo(texto)) {
        _resultado = 'Si es palindromo';
      } else {
        _resultado = 'No es palindromo';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Palidromos Game'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _textController,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Ingresa una palabra',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: _verificarPalindromo,
              child: Text('Enter'),
            ),
            SizedBox(height: 16.0),
            Text(
              _resultado,
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
