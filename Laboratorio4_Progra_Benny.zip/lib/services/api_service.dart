import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/article.dart';

class ApiService {
  final String _baseUrl = 'https://newsapi.org/v2';
  final String _apiKey = '789e5d0910bf4dd49526c541f2c03a18';

  Future<List<Article>> fetchArticles() async {
    final response = await http.get(Uri.parse('$_baseUrl/top-headlines?country=us&apiKey=$_apiKey'));

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      final List<dynamic> articlesJson = data['articles'];
      return articlesJson.map((json) => Article.fromJson(json)).toList();
    } else {
      throw Exception('Error');
    }
  }
}
