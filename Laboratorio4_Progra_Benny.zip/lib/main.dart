import 'package:flutter/material.dart';
import 'services/api_service.dart'; 
import 'models/article.dart'; 

class NewsApp extends StatelessWidget {
  final ApiService apiService = ApiService();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'News App',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Laboratorio'),
        ),
        body: FutureBuilder<List<Article>>(
          future: apiService.fetchArticles(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            } else if (snapshot.hasData) {
              return ListView.builder(
                itemCount: snapshot.data?.length ?? 0,
                itemBuilder: (context, index) {
                  final article = snapshot.data![index];
                  return ListTile(
                    title: Text(article.title),
                    subtitle: Text(article.description),
                    leading: article.urlToImage != ''
                        ? Image.network(article.urlToImage, width: 100, fit: BoxFit.cover)
                        : null,
                  );
                },
              );
            } else {
              return Center(child: Text('No hay datos disponibles'));
            }
          },
        ),
      ),
    );
  }
}

void main() {
  runApp(NewsApp());
}
